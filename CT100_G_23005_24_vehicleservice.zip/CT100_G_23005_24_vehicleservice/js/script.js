// AutoCare Garage - service booking: validation, live estimate and dynamic messages.

document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("serviceForm");
    const errorBox = document.getElementById("error-box");
    const typeSelect = document.getElementById("type");
    const yearInput = document.getElementById("year");
    const serviceBoxes = document.querySelectorAll('input[name="services[]"]');

    const typeDescriptions = {
        "Saloon Car": "Saloon cars usually need oil changes, brake checks and wheel alignment.",
        "SUV": "SUVs are heavier, so brake inspection and wheel alignment are recommended.",
        "Pickup": "Pickups often carry loads; check brakes and alignment regularly.",
        "Van": "Vans carry heavy loads; a Full Service is advised for longer trips."
    };

    // Events: submit (validation), change (type info and services), input (vehicle age).
    form.addEventListener("submit", validateServiceForm);
    typeSelect.addEventListener("change", showVehicleInfo);
    serviceBoxes.forEach(box => box.addEventListener("change", calculateServiceCost));
    yearInput.addEventListener("input", checkVehicleAge);

    // Function 1: validate all fields; block submission if any check fails.
    function validateServiceForm(event) {
        const fields = {
            name: document.getElementById("name"),
            phone: document.getElementById("phone"),
            email: document.getElementById("email"),
            reg_no: document.getElementById("reg_no"),
            type: typeSelect,
            model: document.getElementById("model"),
            year: yearInput,
            date: document.getElementById("date")
        };
        const errors = [];
        const currentYear = new Date().getFullYear();

        const markInvalid = (key, invalid) => fields[key].classList.toggle("invalid", invalid);
        Object.keys(fields).forEach(key => markInvalid(key, false));

        if (fields.name.value.trim() === "") { errors.push("Customer name is required."); markInvalid("name", true); }
        if (!/^\d{10}$/.test(fields.phone.value.trim())) { errors.push("Phone number must contain exactly 10 digits."); markInvalid("phone", true); }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.value.trim())) { errors.push("A valid email address is required."); markInvalid("email", true); }
        if (fields.reg_no.value.trim() === "") { errors.push("Vehicle registration number is required."); markInvalid("reg_no", true); }
        if (fields.type.value === "") { errors.push("Please select a vehicle type."); markInvalid("type", true); }
        if (fields.model.value.trim() === "") { errors.push("Vehicle model is required."); markInvalid("model", true); }

        const year = Number(fields.year.value);
        if (fields.year.value === "" || year < 1970 || year > currentYear) {
            errors.push(`Year of manufacture must be between 1970 and ${currentYear}.`);
            markInvalid("year", true);
        }
        if (fields.date.value === "") { errors.push("Please choose a preferred service date."); markInvalid("date", true); }

        const anyChecked = Array.from(serviceBoxes).some(box => box.checked);
        if (!anyChecked) errors.push("Select at least one service.");

        if (errors.length > 0) {
            event.preventDefault();
            errorBox.classList.remove("hidden");
            errorBox.innerHTML = "<strong>Please fix the following:</strong><br>" + errors.join("<br>");
            window.scrollTo(0, 0);
        } else {
            errorBox.classList.add("hidden");
        }
    }

    // Function 2: show the chosen vehicle type's note.
    function showVehicleInfo() {
        const info = document.getElementById("type-info");
        const text = typeDescriptions[typeSelect.value];
        info.textContent = text || "";
        info.classList.toggle("hidden", !text);
    }

    // Function 3: recalculate the total and update the selected-services list and count.
    function calculateServiceCost() {
        let total = 0;
        const selected = [];
        serviceBoxes.forEach(box => {
            if (box.checked) {
                total += parseInt(box.dataset.price, 10);
                selected.push(box.value);
            }
        });

        document.getElementById("total-cost").textContent = total.toLocaleString("en-US");
        document.getElementById("service-count").textContent = selected.length;

        const list = document.getElementById("selected-list");
        list.innerHTML = "";
        if (selected.length === 0) {
            list.innerHTML = "<li>None selected</li>";
        } else {
            selected.forEach(name => {
                const li = document.createElement("li");
                li.textContent = name;
                list.appendChild(li);
            });
        }
    }

    // Function 4: show the age warning for vehicles older than 15 years.
    function checkVehicleAge() {
        const year = parseInt(yearInput.value, 10);
        const currentYear = new Date().getFullYear();
        const isOld = !isNaN(year) && (currentYear - year) > 15;
        document.getElementById("age-warning").classList.toggle("hidden", !isOld);
    }

    calculateServiceCost();
});
