<?php
// AutoCare Garage - server-side processing.
// The server validates every field and recalculates the cost itself;
// it never trusts totals or prices sent from the browser.

// Official price list (must match service.html).
$servicePrices = [
    "Engine Oil Change"          => 3000,
    "Brake Inspection"           => 2000,
    "Wheel Alignment"            => 2500,
    "Computer Diagnosis"         => 3500,
    "Full Service"               => 8000,
    "Vehicle Pickup and Delivery" => 1500,
];
$allowedTypes = ["Saloon Car", "SUV", "Pickup", "Van"];

// Escape output to prevent HTML injection.
function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Read a trimmed POST value, or an empty string if it was not sent.
function postValue($key) {
    return isset($_POST[$key]) ? trim((string) $_POST[$key]) : "";
}

// Only accept submissions from the form.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: service.html");
    exit;
}

$name    = postValue("name");
$phone   = postValue("phone");
$email   = postValue("email");
$regNo   = postValue("reg_no");
$type    = postValue("type");
$model   = postValue("model");
$year    = postValue("year");
$date    = postValue("date");
$chosen  = (isset($_POST["services"]) && is_array($_POST["services"])) ? $_POST["services"] : [];

// Server-side validation.
$errors = [];
if ($name === "")                                   $errors[] = "Customer name is required.";
if (!preg_match('/^\d{10}$/', $phone))              $errors[] = "Phone number must contain exactly 10 digits.";
if (!filter_var($email, FILTER_VALIDATE_EMAIL))     $errors[] = "A valid email address is required.";
if ($regNo === "")                                  $errors[] = "Vehicle registration number is required.";
if (!in_array($type, $allowedTypes, true))          $errors[] = "Please select a valid vehicle type.";
if ($model === "")                                  $errors[] = "Vehicle model is required.";

$yearInt = filter_var($year, FILTER_VALIDATE_INT);
$currentYear = (int) date("Y");
if ($yearInt === false || $yearInt < 1970 || $yearInt > $currentYear) {
    $errors[] = "Year of manufacture must be between 1970 and $currentYear.";
}

$dateObj = DateTime::createFromFormat("Y-m-d", $date);
if ($date === "" || !$dateObj || $dateObj->format("Y-m-d") !== $date) {
    $errors[] = "A valid preferred service date is required.";
}

// Keep only services that exist in the official price list.
$validServices = [];
foreach ($chosen as $service) {
    if (is_string($service) && array_key_exists($service, $servicePrices)) {
        $validServices[] = $service;
    }
}
if (count($validServices) === 0) {
    $errors[] = "At least one valid service must be selected.";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AutoCare Garage - Service Request</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <header>
        <div class="brand"><i class="fa-solid fa-car-side"></i> AutoCare<span>.</span> Garage</div>
        <nav>
            <a href="index.html"><i class="fa-solid fa-house"></i> Home</a>
            <a href="service.html"><i class="fa-solid fa-calendar-plus"></i> Book Service</a>
        </nav>
    </header>
    <main>
<?php if (count($errors) > 0): ?>
        <div class="error-box">
            <h2>Request not accepted</h2>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= e($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <p><a class="btn" href="service.html"><i class="fa-solid fa-arrow-left"></i> Go back and correct the form</a></p>
<?php else:
    // Recalculate the total on the server from the validated services.
    $total = 0;
    foreach ($validServices as $service) {
        $total += $servicePrices[$service];
    }
    $formattedDate = $dateObj->format("j F Y");
?>
        <div class="card confirm">
            <h2><i class="fa-solid fa-circle-check"></i> Service request received</h2>
            <div class="detail-grid">
                <div class="detail"><small>Customer</small><strong><?= e($name) ?></strong></div>
                <div class="detail"><small>Phone</small><strong><?= e($phone) ?></strong></div>
                <div class="detail"><small>Email</small><strong><?= e($email) ?></strong></div>
                <div class="detail"><small>Service date</small><strong><?= e($formattedDate) ?></strong></div>
                <div class="detail"><small>Vehicle</small><strong><?= e($regNo) ?> · <?= e($model) ?> (<?= e($yearInt) ?>)</strong></div>
                <div class="detail"><small>Vehicle type</small><strong><?= e($type) ?></strong></div>
            </div>
            <h3>Selected services</h3>
            <ul>
                <?php foreach ($validServices as $service): ?>
                    <li><?= e($service) ?> (KSh <?= number_format($servicePrices[$service]) ?>)</li>
                <?php endforeach; ?>
            </ul>
            <div class="total-box">
                <div class="total-label">Estimated service cost</div>
                <div class="total">KSh <?= number_format($total) ?></div>
            </div>
            <p style="margin-top:20px;">Thank you for choosing AutoCare Garage.</p>
            <p><a class="btn" href="index.html"><i class="fa-solid fa-house"></i> Return to home</a></p>
        </div>
<?php endif; ?>
    </main>
    <footer>&copy; 2026 AutoCare Garage. All rights reserved.</footer>
</body>
</html>
